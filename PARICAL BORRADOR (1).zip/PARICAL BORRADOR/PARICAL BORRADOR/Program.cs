﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

class Expediente
{
    public string Codigo { get; set; } = "";
    public string Ciudadano { get; set; } = "";
    public string Asunto { get; set; } = "";
    public DateTime Fecha { get; set; }

    public override string ToString()
    {
        return "Código: " + Codigo +
               " | Ciudadano: " + Ciudadano +
               " | Asunto: " + Asunto +
               " | Fecha: " + Fecha.ToString("dd/MM/yyyy");
    }
}

class Program
{
    static List<Expediente> expedientes = new List<Expediente>();

    static readonly string archivo = Path.Combine(
        AppDomain.CurrentDomain.BaseDirectory, "expedientes.txt");

    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        CargarExpedientes();

        int opcion;
        do
        {
            Console.Clear();
            Console.WriteLine("====================================");
            Console.WriteLine("       MESA DE PARTES DIGITAL");
            Console.WriteLine("====================================");
            Console.WriteLine("1. Registrar expediente");
            Console.WriteLine("2. Mostrar expedientes");
            Console.WriteLine("3. Buscar expediente por código");
            Console.WriteLine("4. Ordenar expedientes");
            Console.WriteLine("5. Validar datos de un expediente");
            Console.WriteLine("6. Guardar expedientes");
            Console.WriteLine("7. Salir");
            Console.WriteLine("====================================");
            Console.Write("Seleccione una opción: ");

            if (!int.TryParse(Console.ReadLine(), out opcion))
                opcion = 0;

            switch (opcion)
            {
                case 1:
                    RegistrarExpediente();
                    break;
                case 2:
                    MostrarExpedientes();
                    break;
                case 3:
                    BuscarExpediente();
                    break;
                case 4:
                    OrdenarExpedientes();
                    break;
                case 5:
                    ValidarExpediente();
                    break;
                case 6:
                    GuardarExpedientes();
                    break;
                case 7:
                    GuardarExpedientes();
                    Console.WriteLine("Programa finalizado.");
                    break;
                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }

            if (opcion != 7)
                Pausar();

        } while (opcion != 7);
    }

    static void RegistrarExpediente()
    {
        Console.Clear();
        Console.WriteLine("--- REGISTRAR EXPEDIENTE ---");

        string codigo = LeerTexto("Código: ").ToUpperInvariant();

        if (expedientes.Any(e =>
            e.Codigo.Equals(codigo, StringComparison.OrdinalIgnoreCase)))
        {
            Console.WriteLine("Error: el código ya existe.");
            return;
        }

        string ciudadano = LeerTexto("Nombre del ciudadano: ");
        string asunto = LeerTexto("Asunto del expediente: ");

        Console.Write("Fecha (dd/MM/yyyy): ");
        string fechaTexto = Console.ReadLine() ?? "";

        DateTime fecha;
        if (!DateTime.TryParseExact(
            fechaTexto,
            "dd/MM/yyyy",
            CultureInfo.InvariantCulture,
            DateTimeStyles.None,
            out fecha))
        {
            Console.WriteLine("Error: la fecha debe tener formato dd/MM/yyyy.");
            return;
        }

        Expediente nuevo = new Expediente
        {
            Codigo = codigo,
            Ciudadano = ciudadano,
            Asunto = asunto,
            Fecha = fecha
        };

        expedientes.Add(nuevo);
        GuardarExpedientes();
        Console.WriteLine("Expediente registrado correctamente.");
    }

    static void MostrarExpedientes()
    {
        Console.Clear();
        Console.WriteLine("--- LISTA DE EXPEDIENTES ---");

        if (expedientes.Count == 0)
        {
            Console.WriteLine("No hay expedientes registrados.");
            return;
        }

        foreach (Expediente e in expedientes)
        {
            Console.WriteLine("------------------------------------");
            Console.WriteLine(e);
        }

        Console.WriteLine("------------------------------------");
        Console.WriteLine("Total de expedientes: " + expedientes.Count);
    }

    static void BuscarExpediente()
    {
        Console.Clear();
        Console.WriteLine("--- BUSCAR EXPEDIENTE ---");

        string codigo = LeerTexto("Ingrese el código: ");
        Expediente encontrado = null;

        // Búsqueda secuencial compatible con C# 7.3.
        foreach (Expediente e in expedientes)
        {
            if (e.Codigo.Equals(
                codigo, StringComparison.OrdinalIgnoreCase))
            {
                encontrado = e;
                break;
            }
        }

        if (encontrado != null)
        {
            Console.WriteLine("Expediente encontrado:");
            Console.WriteLine(encontrado);
        }
        else
        {
            Console.WriteLine("No se encontró el expediente.");
        }
    }

    static void OrdenarExpedientes()
    {
        Console.Clear();
        Console.WriteLine("--- ORDENAR EXPEDIENTES ---");
        Console.WriteLine("1. Por código");
        Console.WriteLine("2. Por nombre del ciudadano");
        Console.WriteLine("3. Por fecha");
        Console.Write("Seleccione el criterio: ");

        int criterio;
        if (!int.TryParse(Console.ReadLine(), out criterio))
        {
            Console.WriteLine("Opción no válida.");
            return;
        }

        switch (criterio)
        {
            case 1:
                expedientes = expedientes
                    .OrderBy(e => e.Codigo, StringComparer.OrdinalIgnoreCase)
                    .ToList();
                break;
            case 2:
                expedientes = expedientes
                    .OrderBy(e => e.Ciudadano, StringComparer.OrdinalIgnoreCase)
                    .ToList();
                break;
            case 3:
                expedientes = expedientes
                    .OrderBy(e => e.Fecha)
                    .ToList();
                break;
            default:
                Console.WriteLine("Criterio no válido.");
                return;
        }

        GuardarExpedientes();
        Console.WriteLine("Expedientes ordenados correctamente.");

        foreach (Expediente e in expedientes)
            Console.WriteLine(e);
    }

    static void ValidarExpediente()
    {
        Console.Clear();
        Console.WriteLine("--- VALIDAR EXPEDIENTE ---");

        string codigo = LeerTexto("Ingrese el código: ");
        Expediente encontrado = null;

        foreach (Expediente e in expedientes)
        {
            if (e.Codigo.Equals(
                codigo, StringComparison.OrdinalIgnoreCase))
            {
                encontrado = e;
                break;
            }
        }

        if (encontrado == null)
        {
            Console.WriteLine("El expediente no existe.");
            return;
        }

        bool valido =
            !string.IsNullOrWhiteSpace(encontrado.Codigo) &&
            !string.IsNullOrWhiteSpace(encontrado.Ciudadano) &&
            !string.IsNullOrWhiteSpace(encontrado.Asunto) &&
            encontrado.Fecha != DateTime.MinValue;

        Console.WriteLine(valido
            ? "El expediente tiene sus campos obligatorios completos."
            : "El expediente presenta datos incompletos.");
    }

    static void GuardarExpedientes()
    {
        try
        {
            // Sintaxis using tradicional compatible con C# 7.3.
            using (StreamWriter escritor = new StreamWriter(
                archivo, false, Encoding.UTF8))
            {
                foreach (Expediente e in expedientes)
                {
                    escritor.WriteLine(
                        e.Codigo + "|" +
                        e.Ciudadano + "|" +
                        e.Asunto + "|" +
                        e.Fecha.ToString("dd/MM/yyyy"));
                }
            }

            Console.WriteLine("Datos guardados correctamente.");
        }
        catch (IOException ex)
        {
            Console.WriteLine("Error al guardar los datos: " + ex.Message);
        }
        catch (UnauthorizedAccessException)
        {
            Console.WriteLine("No hay permisos para guardar el archivo.");
        }
    }

    static void CargarExpedientes()
    {
        if (!File.Exists(archivo))
            return;

        try
        {
            string[] lineas = File.ReadAllLines(archivo, Encoding.UTF8);

            foreach (string linea in lineas)
            {
                string[] datos = linea.Split('|');

                if (datos.Length != 4)
                    continue;

                DateTime fecha;
                if (!DateTime.TryParseExact(
                    datos[3],
                    "dd/MM/yyyy",
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.None,
                    out fecha))
                    continue;

                if (string.IsNullOrWhiteSpace(datos[0]) ||
                    string.IsNullOrWhiteSpace(datos[1]) ||
                    string.IsNullOrWhiteSpace(datos[2]))
                    continue;

                bool codigoDuplicado = expedientes.Any(e =>
                    e.Codigo.Equals(
                        datos[0], StringComparison.OrdinalIgnoreCase));

                if (codigoDuplicado)
                    continue;

                expedientes.Add(new Expediente
                {
                    Codigo = datos[0],
                    Ciudadano = datos[1],
                    Asunto = datos[2],
                    Fecha = fecha
                });
            }
        }
        catch (IOException ex)
        {
            Console.WriteLine("Error al cargar los datos: " + ex.Message);
        }
        catch (UnauthorizedAccessException)
        {
            Console.WriteLine("No hay permisos para leer el archivo.");
        }
    }

    static string LeerTexto(string mensaje)
    {
        Console.Write(mensaje);
        string texto = (Console.ReadLine() ?? "").Trim();

        while (string.IsNullOrWhiteSpace(texto) || texto.Contains("|"))
        {
            Console.WriteLine(
                "El campo no puede estar vacío ni contener el carácter |.");
            Console.Write(mensaje);
            texto = (Console.ReadLine() ?? "").Trim();
        }

        return texto;
    }

    static void Pausar()
    {
        Console.WriteLine();
        Console.WriteLine("Presione una tecla para continuar...");
        Console.ReadKey();
    }
}
